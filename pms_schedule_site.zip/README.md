# PMS Schedule Website 🚗

This is a simple Preventive Maintenance Schedule (PMS) tracker for vehicles.

### Features
- Add new vehicle PMS records (Plate, Model, Last PMS, Next PMS).
- Displays status as **Upcoming, Due Today, or Due** automatically.
- Built with **HTML + TailwindCSS + JavaScript**.
- No backend required — runs entirely in the browser.

### Deployment
- Upload `index.html` to GitHub repository.
- Enable GitHub Pages under **Settings → Pages**.
- Your PMS website will be live! 🎉
